# geeksforgeeks srmist - desire2service web (NGO)
GeeksforGeeks SRMIST Technical Domain Task Round ..
 
YOU CAN GO THROUGH A LIVE DEMO FOR THIS PROJECT:
https://desiretoservice.blogspot.com/

( Live Project Is Responsive For Both Mobile & Desktop )
